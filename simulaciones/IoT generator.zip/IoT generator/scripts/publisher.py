#Publisher
import random
import time
time.sleep(random.randint(0, 100))
node.publish("AQ/Config/"+str(node.id())+"/Lat", node.latitude)
time.sleep(random.randint(0, 100))
node.publish("AQ/Config/"+str(node.id())+"/Long", node.longitude)

while node.loop():
	node.publish("AQ/Measurement/"+str(node.id())+"/CO", random.randint(100, 600))
	node.publish("AQ/Measurement/"+str(node.id())+"/CO2", random.randint(10, 200))
	node.publish("AQ/Measurement/"+str(node.id())+"/PM2.5", random.randint(0, 10))
	time.sleep(random.randint(0, 100))